# StudyFlow

Aplicação web de produtividade académica: organiza tarefas, calendário, exames, disciplinas e notas, com temporizador Pomodoro, estatísticas, objetivos e música de estudo. Funciona só no navegador, sem conta e sem servidor.

**Demonstração:** https://gc059881-byte.github.io/StudyFlow/ (depois de publicares esta versão)

## Funcionalidades

- **Dashboard** com próxima prioridade, próximo exame, foco de hoje e da semana, e atividade recente.
- **Tarefas** com prioridade, prazo, etiquetas, pesquisa, filtros e ordenação.
- **Calendário** mensal com tarefas, exames, sessões e eventos próprios.
- **Pomodoro** com durações configuráveis. O tempo é calculado pela hora de fim, por isso continua certo com o separador em segundo plano. Cada sessão fica associada a uma disciplina.
- **Exames** com tópicos de preparação e contagem de dias.
- **Disciplinas** como espaços de trabalho: visão geral, estudo, notas, avaliações, trabalhos com subtarefas, Pomodoro, portefólio, materiais, tarefas, objetivos e progresso. As tarefas, notas e exames são os mesmos registos das páginas globais.
- **Notas** com guardado automático e pré-visualização Markdown segura.
- **Estatísticas, objetivos e conquistas** calculados a partir do histórico real (o XP não se duplica).
- **Música de estudo** gerada no navegador (Web Audio, sem ficheiros de áudio): piano, lo-fi, ambiente, chuva, clássica e concentração. Só toca depois de carregares em Reproduzir.
- **Definições:** tema claro/escuro, durações, notificações, exportar/importar cópia de segurança (JSON) e repor dados.
- Vídeo de fundo silencioso, parado com movimento reduzido ou poupança de dados.

## Como correr localmente

Não precisa de compilação. Abre `index.html` no navegador, ou serve a pasta:

```bash
python3 -m http.server 8000
# abre http://localhost:8000
```

Precisa de internet para carregar as bibliotecas Chart.js e Lucide (CDN) e o tipo de letra do Google Fonts.

## Publicar no GitHub Pages

```bash
git init
git add .
git commit -m "StudyFlow: versão inicial"
git branch -M main
git remote add origin https://github.com/<utilizador>/StudyFlow.git
git push -u origin main
```

Depois, no repositório: **Settings → Pages → Build and deployment → Deploy from a branch → `main` / `(root)` → Save**. O site fica em `https://<utilizador>.github.io/StudyFlow/` ao fim de um ou dois minutos.

Se o repositório já tem a versão anterior do site, faz uma cópia de segurança ou cria uma branch antes do `push`.

## Estrutura

```
index.html        página e estrutura
css/style.css     sistema de design (temas claro e escuro)
js/app.js         lógica, páginas, Pomodoro, música e armazenamento
assets/bg.mp4     vídeo de fundo (1280 px, sem áudio)
assets/poster.jpg fotograma de reserva
assets/favicon.svg
```

## Dados e privacidade

Tudo fica no `localStorage` do navegador. Não há sincronização entre dispositivos: usa **Definições → Exportar JSON** para guardar uma cópia e **Importar JSON** para a recuperar.

## Limitações conhecidas

- O portefólio e os materiais guardam apenas ligações (http/https), não ficheiros nem imagens.
- O calendário tem vista mensal; as vistas semanal e diária não existem.
- A música é sintetizada, por isso não soa como gravações reais.

## Créditos e licença

- Bibliotecas: [Chart.js](https://www.chartjs.org/) e [Lucide](https://lucide.dev/), carregadas por CDN. Tipos de letra: Bricolage Grotesque e Figtree (Google Fonts).
- Vídeo de fundo: confirma a origem e a licença do ficheiro antes de publicar e acrescenta aqui o crédito.
- Licença do código: por definir. Escolhe uma (por exemplo MIT) e acrescenta um ficheiro `LICENSE`.
